/**
 *
 * @author Felice Tortorelli & Sorangelo Angelo
 */
package Grafo;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;

public class Nodo implements Serializable {
    private String parola;
    private ArrayList<Arco> archi;

    public Nodo(String parola) {
        this.parola = parola;
        archi = new ArrayList<Arco>();
    }


    public String getParola() {
        return parola;
    }

    public ArrayList<Arco> getArchi() {
        return archi;
    }

    public int contiene(String s) {
        int i = 0;
        for (Arco a : archi) {
            if (a.getNodo().getParola() == s) {
                return i;
            }
            i++;
        }
        return -1;
    }

    public void addArco(Nodo n, String before) {
        int i = contiene(n.parola);
        if (i == -1) {
            Arco arco;
            if(before == null)
                arco = new Arco(n);
            else
                arco = new Arco(n,before);
            archi.add(arco);
        } else {
            archi.get(i).incPeso();
            if(before != null){
                archi.get(i).addPrec(before);
            }
        }
        Collections.sort(archi);
    }
}
