/**
 *
 * @author Felice Tortorelli & Sorangelo Angelo
 */
package Grafo;

import java.io.Serializable;
import java.util.HashMap;

public class Arco implements Comparable, Serializable {
    private Nodo n;
    private int peso;
    private HashMap<String,Integer> prec;

    public Arco(Nodo n) {
        this.n = n;
        peso = 1;
        prec = new HashMap<String, Integer>();
    }

    public Arco(Nodo n, String before) {
        this.n = n;
        peso = 1;
        prec = new HashMap<String, Integer>();
        prec.put(before, 1);
    }

    public void incPeso() {
        peso += 1;
    }

    public void incPesoPrec(String s) {
        prec.replace(s,prec.get(s)+1);
    }

    public Nodo getNodo() {
        return n;
    }

    public int getPeso() {
        return peso;
    }

    public void addPrec(String s){
        if(prec.containsKey(s)){
            int i = prec.get(s);
            prec.replace(s, i+1);
        } else {
            prec.put(s, 1);
        }
    }

    public HashMap<String,Integer> getPrec(){
        return prec;
    }

    public int compareTo(Object o) {
        Arco a = (Arco) o;
        if (a.getPeso() - this.peso > 0) return 1;
        else if (a.getPeso() - this.peso < 0) return -1;
        else return 0;
    }
}