/**
 *
 * @author Felice Tortorelli & Sorangelo Angelo
 */
package Grafo;

import java.io.*;
import java.sql.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

public class Grafo implements Serializable {

    private HashMap<String, Nodo> grafo;

    public Grafo(String path) {
        ObjectInputStream ois = null;

        try {
            File f = new File(path);
            if (!f.exists()) {
                grafo = new HashMap<String, Nodo>();
                addNodo("#");
            } else {
                ois = new ObjectInputStream(new FileInputStream(path));
                grafo = (HashMap<String, Nodo>) ois.readObject();
                ois.close();
            }
        } catch (Exception e) {
            System.out.println("\nIl Grafo non Ã¨ stato caricato correttamente!Riprova");
        }
    }

    public void addNodo(String current, String last, String before) {
        if (!grafo.containsKey(current)) {
            addNodo(current);
        }
        grafo.get(last).addArco(grafo.get(current), before);
    }

    public void addNodo(String let) {
        Nodo n = new Nodo(let);
        grafo.put(let, n);
    }

    public Nodo getNodo(String str) {
        return grafo.get(str);
    }

    private class Strsug {
        private String str;
        private int peso;

        public Strsug(String s, int i) {
            str = s;
            peso = i;
        }
    }

    public ArrayList<String> suggerimenti(String current, String last, String before) {
        Nodo n;
        ArrayList<Arco> suggArc;
        ArrayList<String> suggStr = new ArrayList<String>();
        ArrayList<Strsug> suggStr2 = new ArrayList<Strsug>();
        //inizio frase o inizio esecuzione
        if (current.contains(".") || current.contains("?") || current.contains("!") || current.contains("#")) {
            current = current.replaceAll("[.?!]+", "");
            if (!current.contains("#")) {
                if (!grafo.containsKey(current)) {
                    addNodo(current);
                }
                n = grafo.get(current);
                Nodo n2 = grafo.get(last);
                if (last == null)
                    n2 = grafo.get("#");
                n2.addArco(n, before);
            }
            n = grafo.get("#");
            suggArc = n.getArchi();
            for (Arco a : suggArc) {
                suggStr.add(a.getNodo().getParola());
            }
            return suggStr;
        } else if (grafo.containsKey(current)) {
            //caso in cui la parola inserita esiste giÃ 
            n = grafo.get(current);

            Nodo n2 = grafo.get(last);
            if (last == null || last.contains(".") || last.contains("?") || last.contains("!")) {

                n2 = grafo.get("#");
                before = null;
            }
            n2.addArco(n, before);
            suggArc = n.getArchi();


            if (last != null && !last.contains("#")) {

                for (Arco a : suggArc) {
                    if (a.getPrec().containsKey(last)) {
                        suggStr2.add(new Strsug(a.getNodo().getParola(), a.getPrec().get(last)));
                    }
                }
                Strsug app = new Strsug("",0);
                for (int i = 0; i < suggStr2.size() - 1; i++) {
                    for (int j = i + 1; j < suggStr2.size(); j++) {
                        if (suggStr2.get(i).peso < suggStr2.get(j).peso) {

                            app.str = suggStr2.get(i).str;
                            app.peso = suggStr2.get(i).peso;
                            suggStr2.get(i).peso = suggStr2.get(j).peso;
                            suggStr2.get(i).str = suggStr2.get(j).str;
                            suggStr2.get(j).peso = app.peso;
                            suggStr2.get(j).str = app.str;
                        }
                    }
                }
                for (Strsug s : suggStr2) {
                    suggStr.add(s.str);
                }
            }

            for (Arco a : suggArc) {
                if (!suggStr.contains(a.getNodo().getParola())) {
                    suggStr.add(a.getNodo().getParola());
                }
            }
        } else {
            //caso in cui la parola inserita non esiste
            if (last == null) { //seconda parola frase
                addNodo(current, "#", null);
            } else if (before == null) { //terza parola frase
                addNodo(current, last, null);
            } else { //successivo alla quarta parola
                addNodo(current, last, before);
            }
            return null;
        }
        return suggStr;
    }

    public void stampa() {
        if (!grafo.isEmpty()) {
            HashMap<String, Nodo> g = new HashMap<String, Nodo>();
            g = (HashMap<String, Nodo>) (grafo.clone());
            Iterator it = g.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry pair = (Map.Entry) it.next();
                System.out.println(pair.getKey() + "=");
                ((Nodo) (pair.getValue())).getArchi().forEach((Arco arco) -> {
                    System.out.println("    " + arco.getNodo().getParola() + ": " + arco.getPeso());
                    arco.getPrec().forEach((String str, Integer p) -> {
                        System.out.println("      " + str + ": " + p);
                    });
                });

                it.remove();
            }
        }


    }

    public boolean esiste(String str) {
        return grafo.containsKey(str);
    }

    public void salvaGr(String path) {
        ObjectOutputStream oss;
        try {
            oss = new ObjectOutputStream(new FileOutputStream(path));
            oss.writeObject(grafo);
            oss.close();
        } catch (Exception e) {
            System.out.println("Errore salvataggio grafo!");
        }

    }

    public ArrayList<String> askSugg(String current, String last) {
        ArrayList<Arco> sugg;
        ArrayList<String> suggStr = new ArrayList<>();
        ArrayList<Strsug> suggStr2 = new ArrayList<>();
        if (grafo.containsKey(current)) {
            sugg = grafo.get(current).getArchi();

            if (last != null) {
                for (Arco a : sugg) {
                    if (a.getPrec().containsKey(last)) {
                        suggStr2.add(new Strsug(a.getNodo().getParola(), a.getPrec().get(last)));
                        System.out.println(a.getNodo().getParola());
                    }
                }
                Strsug app = new Strsug("",0);
                for (int i = 0; i < suggStr2.size() - 1; i++) {
                    for (int j = i + 1; j < suggStr2.size(); j++) {
                        if (suggStr2.get(i).peso < suggStr2.get(j).peso) {
                            app.str = suggStr2.get(i).str;
                            app.peso = suggStr2.get(i).peso;
                            suggStr2.get(i).peso = suggStr2.get(j).peso;
                            suggStr2.get(i).str = suggStr2.get(j).str;
                            suggStr2.get(j).peso = app.peso;
                            suggStr2.get(j).str = app.str;
                        }
                    }
                }

                for (Strsug s : suggStr2) {
                    suggStr.add(s.str);
                }
            }
            if(!suggStr.isEmpty())
                suggStr.add("------------------------------");
            for (Arco a : sugg) {
                if (!suggStr.contains(a.getNodo().getParola())) {
                    suggStr.add(a.getNodo().getParola());
                }
            }
        }
        return suggStr;
    }

    public ArrayList<Nodo> getParents(String s) {
        Nodo n = grafo.get(s);
        ArrayList<Nodo> gen = new ArrayList<Nodo>();
        HashMap<String, Nodo> g;
        g = (HashMap<String, Nodo>) (grafo.clone());
        ArrayList<Arco> arc;
        Iterator it = g.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            arc = ((Nodo) (pair.getValue())).getArchi();
            for (Arco a : arc) {
                if (a.getNodo().getParola() == n.getParola()) {
                    gen.add((Nodo) (pair.getValue()));
                }
            }
            it.remove();
        }
        return gen;
    }

    public ArrayList<Nodo> getSon(String s) {
        ArrayList<Nodo> son = new ArrayList<Nodo>();
        for (Arco a : grafo.get(s).getArchi()) {
            son.add(a.getNodo());
        }
        return son;
    }
}
