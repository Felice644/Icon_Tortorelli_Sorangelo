/**
 *
 * @author Felice Tortorelli & Sorangelo Angelo
 */

package INTERF_GUI;

import CONTROLLO.Control;
import javax.swing.*;
import java.util.ArrayList;
import javax.swing.GroupLayout.Alignment;

public class ASKGUY extends javax.swing.JFrame {

    /**
     * classe che realizza l'interfaccia che permette all'utente di visionare la struttura del grafo in base al nodo inserito
     */
    Control control;
    ArrayList<String> sugg;

    public ASKGUY() {
        control = new Control("Grafo");
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        btnTips = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea = new javax.swing.JTextArea();
        txtLast = new javax.swing.JTextField();
        txtCurrent = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();

        jLabel1.setText("jLabel1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnTips.setText("CONSIGLI");
        btnTips.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTipsActionPerformed(evt);
            }
        });

        jTextArea.setColumns(30);
        jTextArea.setRows(5);
        jScrollPane2.setViewportView(jTextArea);
        txtLast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtLastActionPerformed(evt);
            }
        });

        txtCurrent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCurrentActionPerformed(evt);
            }
        });
        setDefaultCloseOperation(this.DO_NOTHING_ON_CLOSE);
        this.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                jTextArea.setText("");
                txtCurrent.setText("");
                txtLast.setText("");
                setVisible(false);
                dispose();
            }
        });

        jLabel2.setText("SUGGERIMENTI");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(Alignment.CENTER)
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(txtLast, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(jLabel2)
                                                        .addComponent(txtCurrent))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(btnTips, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 372, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(5, 5, 5))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(btnTips, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtLast, javax.swing.GroupLayout.DEFAULT_SIZE, 34, Short.MAX_VALUE)
                                        .addComponent(txtCurrent))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>

    private void txtLastActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
    }

    private void txtCurrentActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
    }

    private void btnTipsActionPerformed(java.awt.event.ActionEvent evt) {
        if (txtCurrent.getText().equals(""))
            sugg = control.getGrafo().askSugg(txtLast.getText().replaceAll(" ", ""), null);
        else
            sugg = control.getGrafo().askSugg(txtCurrent.getText().replaceAll(" ", ""), txtLast.getText().replaceAll(" ", ""));
        if (!sugg.isEmpty()) {
            jTextArea.setText("");
            jTextArea.setText("");
            for (String s : sugg) {
                jTextArea.append(s + "\n");
            }
        } else {
            jTextArea.setText("\nNon esistono ancora suggerimenti per questa parola.");
        }
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ASKGUY().setVisible(true);
            }
        });
    }

    private javax.swing.JButton btnTips;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea;
    private javax.swing.JTextField txtCurrent;
    private javax.swing.JTextField txtLast;
}
