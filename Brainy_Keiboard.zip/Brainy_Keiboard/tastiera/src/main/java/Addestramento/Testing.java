/**
 *
 * @author Felice Tortorelli & Sorangelo Angelo
 */
package Addestramento;


import Grafo.Grafo;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Testing {
    public static void main(String args[]) {
        try {
            File myObj = new File("src\\main\\java\\Addestramento\\TESTO1.txt");
            
            Scanner myReader = new Scanner(myObj);
            String data = "";
            while (myReader.hasNextLine()) {
                data += myReader.nextLine() + " ";
            }
            myReader.close();

            data = data.replaceAll("[:,';\\/()\\[\\][0-9]<>«»\\-\"—_#=]+", " ").toLowerCase();
            String[] tokens = data.split("[.!?]");
            Grafo grafo = new Grafo("Grafo");
            long denom=0, num=0;
            for (String token : tokens) {
                ArrayList<String> sugg;
                String[] tok = token.split(" ");
                String last = "";
                String before = "";
                for (int i=0; i < tok.length; i++) {
                    if (tok[i].length() > 0 && !tok[i].equals(" ")) {
                        denom++;
                        int j = i;
                        int k = 1;
                        while (j >= k) {
                            if (tok[i - k].length() > 0) {
                                last = tok[i - k];
                                break;
                            }
                            k++;
                            j--;
                        }

                        j = i;
                        k = 2;
                        while (j >= k) {
                            if (tok[i - k].length() > 0) {
                                before = tok[i - k];
                                break;
                            }
                            k++;
                            j--;
                        }

                        if (last == null || last.equals("")) {
                            sugg = grafo.suggerimenti(tok[i], null, null);
                        } else if (before == null || before.equals("")) {
                            sugg = grafo.suggerimenti(tok[i], last, null);
                        } else {
                            sugg = grafo.suggerimenti(tok[i], last, before);
                        }
                      if (i < tok.length - 1) {
                            if (sugg != null && ((sugg.size()>0 && tok[i + 1].equals(sugg.get(0))) || (sugg.size()>1 && tok[i + 1].equals(sugg.get(1))) || (sugg.size()>2 && tok[i + 1].equals(sugg.get(2)))))
                                num++;
                      } else {
                          denom--;
                      }
                    }
                }
            }

            System.out.println("\nSalvataggio dei dati");
            grafo.salvaGr("Grafo");
            System.out.println("\nSalvataggio avvenuto con successo!");
        } catch (FileNotFoundException e) {
            System.out.println("\nE' stato riscontrato un errore");
            e.printStackTrace();
        }
    }

}