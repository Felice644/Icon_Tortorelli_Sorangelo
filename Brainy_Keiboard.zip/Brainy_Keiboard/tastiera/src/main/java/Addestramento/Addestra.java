package Addestramento;

/**
 *
 * @author Felice Tortorelli & Sorangelo Angelo
 */

import Grafo.Grafo;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Locale;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Addestra {
    public static void main(String args[]) {
        try {
            File myObj = new File("src\\main\\java\\Addestramento\\TRAININGSET.txt");
            Scanner myReader = new Scanner(myObj);
            String data = "";
            while (myReader.hasNextLine()) {
                data += myReader.nextLine() + " ";
            }
            myReader.close();
            data = data.replaceAll("[:,';\\/()\\[\\][0-9]<>«»\\-\"—_#=]+", " ").toLowerCase();
            String[] tokens = data.split("[.!?]");
            Grafo grafo = new Grafo("Grafo");
            for (String token : tokens) {
                boolean first = true;
                boolean second = true;
                String before = "";
                String[] tok = token.split(" ");
                String last = "";
                for (String t : tok) {
                    if (t.length() > 0) {
                        if (first) {//gestione prima parola della frase
                            grafo.addNodo(t, "#", null);
                            first = false;
                        } else if(second) {//resto delle parole
                            grafo.addNodo(t, last, null);
                            second = false;
                        }else{
                            grafo.addNodo(t, last, before);

                        }
                        before = last;
                        last = t;
                    }

                }
            }
            System.out.println("\nSalvataggio dei dati");
            grafo.salvaGr("Grafo");
            System.out.println("\nSalvataggio avvenuto con successo!");
        } catch (FileNotFoundException e) {
            System.out.println("\nE' stato riscontrato un errore");
            e.printStackTrace();
        }
    }
}
