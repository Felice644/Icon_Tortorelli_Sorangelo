/**
 *
 * @author Felice Tortorelli & Sorangelo Angelo
 */
package CONTROLLO;

import Grafo.Grafo;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

public class Control {

    private String text;
    private Grafo grafo;
    private ArrayList<String> sugge;
    private String current;
    private String last;
    private String before;
    private boolean first;

    public Control(String path) {
        text = "";
        grafo = new Grafo(path);
        sugge = grafo.suggerimenti("#", null, null);
        first = true;

    }

    public void spazio(String ptr) {
        sugge = grafo.suggerimenti(current, last, before);
        if (first) {

            grafo.salvaGr(ptr);
            first = false;
        }
    }
    public Grafo getGrafo(){
        return grafo;
    }

    public boolean setText(String text) {
        this.text = text.toLowerCase();
        text = text.replaceAll("[:,';\\/()\\[\\][0-9]<>Â«Â»\\-\"â€”_#=\n\r]+", " ");
        String[] splits = text.split(" ");
        if(splits.length!=0){
            current = splits[splits.length - 1];
            if(current != null){
                last = null;
                before = null;
                int i = splits.length;
                int k = 2;
                while (i >= k) {
                    if (splits[splits.length - k].length() > 0) {
                        last = splits[splits.length - k];
                        break;
                    }
                    k++;
                    i--;
                }
                if(last == null || last.contains(".") || last.contains("?") || last.contains("!")){
                    last = null;
                }else{
                    i = splits.length;
                    k = 3;
                    while (i >= k) {
                        if (splits[splits.length - k].length() > 0) {
                            before = splits[splits.length - k];
                            break;
                        }
                        k++;
                        i--;
                    }
                    if(before == null || before.contains(".") || before.contains("?") || before.contains("!"))
                        before = null;
                }
                return true;
            }
        }
        return false;
    }

    public ArrayList<String> getSugge() {
        return sugge;
    }

    public ArrayList<String> filter() {
        ArrayList<String> tip = new ArrayList<String>();
        ArrayList<String> best3 = new ArrayList<String>();


        if (sugge != null) {
            for (String s : sugge)
                if (s.matches(current + "[a-z]*")) {
                    tip.add(s);
                }

            if (tip.size() >= 1) {
                best3.add(tip.get(0));
            }
            if (tip.size() >= 2) {
                best3.add(tip.get(1));
            }
            if (tip.size() >= 3) {
                best3.add(tip.get(2));
            }
        }

        return best3;
    }


}
